
import React from "react";

export default function WorkersRights() {
  return (
    <div className="min-h-screen bg-gray-50 p-6 text-gray-800">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold text-blue-700">حقوق العمالة</h1>
        <p className="mt-2 text-lg">تعرف على حقوقك كعامل في بيئة العمل</p>
      </header>

      <main className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <section className="bg-white p-6 rounded-2xl shadow">
          <h2 className="text-2xl font-semibold mb-2">1. الحق في الأجر العادل</h2>
          <p>
            يحق للعامل الحصول على أجر عادل مقابل عمله يتناسب مع الجهد المبذول ويُدفع في الوقت المحدد.
          </p>
        </section>

        <section className="bg-white p-6 rounded-2xl shadow">
          <h2 className="text-2xl font-semibold mb-2">2. بيئة عمل آمنة</h2>
          <p>
            يجب توفير بيئة عمل خالية من المخاطر وتقديم معدات السلامة والتدريب اللازم.
          </p>
        </section>

        <section className="bg-white p-6 rounded-2xl shadow">
          <h2 className="text-2xl font-semibold mb-2">3. ساعات العمل والراحة</h2>
          <p>
            يحق للعامل الحصول على ساعات عمل محددة واستراحات كافية ويوم راحة أسبوعي.
          </p>
        </section>

        <section className="bg-white p-6 rounded-2xl shadow">
          <h2 className="text-2xl font-semibold mb-2">4. عدم التمييز</h2>
          <p>
            يجب معاملة جميع العمال بعدالة بغض النظر عن الجنسية أو الجنس أو الدين.
          </p>
        </section>

        <section className="bg-white p-6 rounded-2xl shadow">
          <h2 className="text-2xl font-semibold mb-2">5. الحق في الشكوى</h2>
          <p>
            يمكن للعمال تقديم شكاوى ضد ظروف العمل غير العادلة دون خوف من الانتقام.
          </p>
        </section>
      </main>

      <footer className="mt-10 text-center text-sm text-gray-500">
        &copy; {new Date().getFullYear()} جميع الحقوق محفوظة.
      </footer>
    </div>
  );
}
